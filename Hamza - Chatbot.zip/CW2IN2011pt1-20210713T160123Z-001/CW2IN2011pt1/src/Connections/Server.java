package Connections;

import java.net.*;
import java.io.*;

/**
 * This is the server that will communicate to the client i.e. the user
 */
public class Server {
    /**
     * Responds to client input
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {


        int portNumber = 20111;

        try (
                ServerSocket serverSocket = new ServerSocket(portNumber);
                Socket clientSocket = serverSocket.accept();
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        ) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                switch (inputLine) {
                    case "1" -> {
                        ServerMessages.About(out);
                        ServerMessages.AnythingElse(out);
                    }
                    case "2" -> {
                        ServerMessages.Services(out);
                        ServerMessages.AnythingElse(out);
                    }
                    case "3" -> {
                        out.println("You can support SkillStruct by going on the following page: " +
                                "\nhttps://skillstruct.com/support/");
                        ServerMessages.AnythingElse(out);
                    }
                    case "4" -> {
                        out.println("You can get in touch here: https://skillstruct.com/contact/");
                        ServerMessages.AnythingElse(out);
                    }
                    case "5" -> {
                        out.println("Goodbye!");
                        System.exit(7);
                    }

                }

                //out.println(inputLine);
            }
        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen on port "
                    + portNumber + " or listening for a connection");
            System.out.println(e.getMessage());
        }
    }
}