package Connections;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

/**
 * This a class where messages from the server to the client are stored
 */

public class ServerMessages {

    /**
     * The first message the user sees
     */
    public static void welcomemessage(){
        System.out.println("Hi. I am Hamza, your virtual assistant at SkillStruct\n" +
                "\nPress 1 to learn more about what we do at SkillStruct\n" +
                "\nPress 2 to see the variety of services we have on offer\n" +
                "\nPress 3 to find out ways to support SkillStruct\n" +
                "\nPress 4 to find out how to get in touch\n" +
                "\nPress 5 to exit the chat"
        );


    }

    /**
     * This prints what SkillStruct is about to the user
     * @param out
     */
    public static void About(PrintWriter out){
        out.println("SkillStruct is a Technology and Early careers consultancy firm.");
        out.println("We specialise in building underrepresented tech and early career talent");
        out.println("and provide young people with an interest in technology a virtual network called SkillStruct University.");
    }

    /**
     * This option is used to allow the user to select other options in the chatbot
     * @param out
     */
    public static void AnythingElse(PrintWriter out){
        out.println("Anything else I can help you with? Please follow the commands listed at the beginning");

    }

    /**
     * This code is desgined to print the services that SkillStruct offer in a more aesthetically pleasing manner
     * Taken from https://itsallbinary.com/java-printing-to-console-in-table-format-simple-code-with-flexible-width-left-align-header-separator-line/
     * @param table
     * @param writer
     */

    public static void simpleTable(String[][] table, PrintWriter writer) {


        boolean leftJustifiedRows = false;

        Map<Integer, Integer> columnLengths = new HashMap<>();
        Arrays.stream(table).forEach(a -> Stream.iterate(0, (i -> i < a.length), (i -> ++i)).forEach(i -> {
            if (columnLengths.get(i) == null) {
                columnLengths.put(i, 0);
            }
            if (columnLengths.get(i) < a[i].length()) {
                columnLengths.put(i, a[i].length());
            }
        }));

        final StringBuilder formatString = new StringBuilder("");
        String flag = leftJustifiedRows ? "-" : "";
        columnLengths.entrySet().stream().forEach(e -> formatString.append("| %" + flag + e.getValue() + "s "));
        formatString.append("|\n");
        //System.out.println("formatString = " + formatString.toString());

        /*
         * Print table
         */
        Stream.iterate(0, (i -> i < table.length), (i -> ++i))
                .forEach(a -> writer.printf(formatString.toString(), table[a]));

    }

    /**
     * The services that SkillStruct offer
     * @param out
     */
    public static void Services(PrintWriter out){
        String[][] table = new String[][] {
                { "Career Coaching: ", "We provide a career coaching service assisting our clients in identifying personal goals,developing leadership skills and planning career moves."},
                { "Establishing Equality Virtual Networks: ", "We work with you from conception to establishing the diverse network, we will then work on a plan to help your organisation sustain the new network by leveraging technology."},
                { "Early Career Tech Recruitment: ", "We leverage the SkillStruct University network and our other affiliated networks to provide tech talent for early careers."},
                { "Equality Mentoring Programs: ", "We provide a 4 monthly program with a set of activities and workshops with the aim to improve early career retention, identify future leaders and enhance productivity" },
                { "Early Careers Pipeline Strategy: ","We work with you on writing/reviewing existing job descriptions for recruitment candidates from diverse backgrounds, we will review existing pipelines and give constructive ways to improve your strategy."},
                { "Equality Workshops: ","We provide a series of talks including understanding Equality in the workplace, Normalizing the conversation on race, and much more"}

        };
        out.println("""
                For the individual we offer services to help improve your chances to kickstart your career.
                We give insights into our experiences and consult your job applications for new positions from start to finish.
                Here are the services we can offer to you:\s"""
        );
        simpleTable(table,out);


    }

}
